package com.imbilalbutt.bilalButtarbisoftv14.service;

import com.imbilalbutt.bilalButtarbisoftv14.models.webData;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.springframework.stereotype.Service;

import java.io.StringReader;
import java.net.http.HttpClient;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

@Service
public class getCsvDataService {

    private final String csv_file_url =
            "https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/"
            + "csse_covid_19_data/time_series_covid19_confirmed_global.csv";

    private List<webData> allStats = new ArrayList<>();

    public void fetchData() {

        try {
            List<webData> tempData = new ArrayList<>();

            HttpClient client = HttpClient.newHttpClient();

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(csv_file_url))
                    .build();

            HttpResponse<String> response =
                    client.send(request, HttpResponse.BodyHandlers.ofString());

            StringReader in = new StringReader(response.body());

            Iterable<CSVRecord> records =
                    CSVFormat.DEFAULT.withFirstRecordAsHeader().parse(in);

            for (CSVRecord record : records) {

                webData data = new webData();

                data.setCountry(record.get("Country/Region"));
                data.setState(record.get("Province/State"));
                data.setLatestCases(Integer.parseInt(record.get(record.size()-1)));

                tempData.add(data);
            }

            this.allStats = tempData;

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<webData> getAllStats() {
        return allStats;
    }
}