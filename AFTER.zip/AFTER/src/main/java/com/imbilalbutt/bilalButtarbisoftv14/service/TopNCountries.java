package com.imbilalbutt.bilalButtarbisoftv14.service;

import com.imbilalbutt.bilalButtarbisoftv14.models.webData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class TopNCountries {

    private int n;

    @Autowired
    private getSortedData sortedData;

    private List<webData> topNConsList;
    private List<webData> singleCountryData;

    public TopNCountries() {
        this.n = 10;
    }

    public TopNCountries(int n) {
        this.n = n;
    }

    // ✅ NO @PostConstruct
    public void topNcountries() {

        List<webData> tempSortedListHolder = sortedData.getAllSortedStats();

        // ✅ Safety check
        if (tempSortedListHolder == null || tempSortedListHolder.isEmpty()) {
            System.out.println("⚠️ No data available for Top N Countries");
            this.topNConsList = new ArrayList<>();
            return;
        }

        List<webData> result = new ArrayList<>();

        int limit = Math.min(n, tempSortedListHolder.size());

        for (int i = 0; i < limit; i++) {

            webData wbd = tempSortedListHolder.get(i);

            System.out.println(
                    wbd.getCountry() + " " +
                    wbd.getState() + " " +
                    wbd.getLatestCases()
            );

            result.addAll(ExtractSingleCountryDetails(wbd.getCountry()));
        }

        this.topNConsList = result;
    }

    // ✅ FIXED METHOD
    public List<webData> ExtractSingleCountryDetails(String country) {

        List<webData> tempCountryData = new ArrayList<>();

        List<webData> allCountryList = sortedData.getAllSortedStats();

        if (allCountryList == null) {
            return tempCountryData;
        }

        for (webData singleWebDataElement : allCountryList) {

            if (singleWebDataElement.getCountry().equals(country)) {
                tempCountryData.add(singleWebDataElement);
            }
        }

        this.singleCountryData = tempCountryData;

        return this.singleCountryData;
    }

    // ✅ SAFE GETTER
    public List<webData> getTopNConsListWithParameter(int n) {

        this.n = n;

        topNcountries();

        return this.topNConsList;
    }
}