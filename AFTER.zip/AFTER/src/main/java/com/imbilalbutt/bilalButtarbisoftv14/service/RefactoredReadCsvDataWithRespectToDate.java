package com.imbilalbutt.bilalButtarbisoftv14.service;

import com.imbilalbutt.bilalButtarbisoftv14.models.NewWebData;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.*;

/**
 * =========================================================
 * ✅ REFACTORED COVID DATA SERVICE (SOLID IMPLEMENTATION)
 * =========================================================
 *
 * BEFORE (VIOLATION VERSION ❌):
 * - One class doing EVERYTHING (Fetch + Parse + Process)
 * - Hardcoded logic (Not flexible ❌)
 * - No extensibility ❌
 * - Tight coupling ❌
 *
 * AFTER (REFACTORING ✅):
 * ✔ Responsibilities separated (SRP ✅)
 * ✔ Features added externally (OCP ✅)
 * ✔ Loose coupling using interfaces (DIP ✅)
 *
 * =========================================================
 */
@Service
public class RefactoredReadCsvDataWithRespectToDate {

    // ✅ SRP: Only configuration (DATA SOURCE)
    private final String csv_file_url =
            "https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/"
                    + "csse_covid_19_data/time_series_covid19_confirmed_global.csv";

    // ✅ SRP: Only storing processed data
    private final List<NewWebData> allStats = new ArrayList<>();

    // ✅ Flexible filtering (NO HARDCODING → OCP ✅)
    private String dateSince = "3/5/20";

    /**
     * =====================================================
     * ✅ OCP IMPLEMENTATION (MAIN CONCEPT)
     * =====================================================
     *
     * Instead of modifying this class:
     * ➜ We inject features dynamically
     *
     * Spring automatically finds:
     * classes implementing CovidFeatureProcessor ✅
     */
    @Autowired(required = false)
    private List<CovidFeatureProcessor> features = new ArrayList<>();

    public void setDate(String dateSince) {
        this.dateSince = dateSince;
    }

    /**
     * =====================================================
     * ✅ MAIN FLOW (CONTROLLED EXECUTION)
     * =====================================================
     *
     * ❌ Before: @PostConstruct → auto crash
     * ✅ Now: MANUAL CALL from Controller
     */
    public void fetchData() {

        try {

            // ✅ SRP: Fetch only
            String csvData = fetchCsvData();

            // ✅ SRP: Parse only
            List<CSVRecord> records = parseCsvData(csvData);

            if (records == null || records.isEmpty()) {
                return;
            }

            // ✅ SRP: Header extraction
            CSVRecord header = records.get(0);
            List<String> dates = extractHeaderDates(header);

            // ✅ OCP FLEXIBILITY (dynamic index)
            int beginIndex = dates.indexOf(this.dateSince);

            if (beginIndex == -1) {
                beginIndex = 4; // fallback
            }

            // ✅ SRP: Convert CSV → Objects
            processCovidData(records, beginIndex);

            /**
             * =====================================================
             * 🔥 OCP MAGIC HAPPENS HERE
             * =====================================================
             *
             * We LOOP over all injected features
             *
             * ➜ No change required in this class
             * ➜ Just add new feature class ✅
             */
            for (CovidFeatureProcessor feature : features) {
                feature.apply(allStats);
            }

            System.out.println("✅ Refactored flow executed");

        } catch (Exception e) {
            System.out.println("❌ Error occurred");
            e.printStackTrace();
        }
    }

    // ✅ SRP: ONLY NETWORK CALL
    private String fetchCsvData() throws Exception {

        HttpClient client = HttpClient.newHttpClient();

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(csv_file_url))
                .build();

        HttpResponse<String> response =
                client.send(request, HttpResponse.BodyHandlers.ofString());

        return response.body();
    }

    // ✅ SRP: ONLY PARSING
    private List<CSVRecord> parseCsvData(String csvData) throws Exception {

        CSVParser parser = CSVParser.parse(csvData, CSVFormat.DEFAULT);

        return parser.getRecords();
    }

    // ✅ SRP: ONLY HEADER LOGIC
    private List<String> extractHeaderDates(CSVRecord header) {

        List<String> dates = new ArrayList<>();

        for (int i = 0; i < header.size(); i++) {
            dates.add(header.get(i));
        }

        return dates;
    }

    // ✅ SRP: ONLY DATA TRANSFORMATION
    private void processCovidData(List<CSVRecord> records, int beginIndex) {

        allStats.clear();

        for (int i = 1; i < records.size(); i++) {

            CSVRecord record = records.get(i);

            List<String> row = new ArrayList<>();

            for (int j = 0; j < record.size(); j++) {
                row.add(record.get(j));
            }

            List<String> filtered =
                    row.subList(beginIndex, row.size());

            allStats.add(new NewWebData(
                    row.get(1),
                    row.get(0),
                    filtered
            ));
        }
    }

    // ✅ ISP FIX (Clean exposure)
    @Bean
    public List<NewWebData> getAllStats() {
        return allStats;
    }
}

/* =========================================================
   ✅ OCP INTERFACE (EXTENSION POINT)
   =========================================================
   ➜ Any NEW feature implements this
*/
interface CovidFeatureProcessor {
    void apply(List<NewWebData> data);
}

/* =========================================================
   🔥 FEATURE 1: FILTER BY COUNTRY
   =========================================================
   ✅ No modification in main class
*/
@org.springframework.stereotype.Component
class CountryFilterFeature implements CovidFeatureProcessor {

    @Override
    public void apply(List<NewWebData> data) {

        data.removeIf(d ->
                !d.getCountry().equalsIgnoreCase("Pakistan"));
    }
}

/* =========================================================
   🔥 FEATURE 2: SORT BY LATEST CASES
   ========================================================= */
@org.springframework.stereotype.Component
class SortByLatestCasesFeature implements CovidFeatureProcessor {

    @Override
    public void apply(List<NewWebData> data) {

        data.sort((a, b) -> {

            List<String> aList = a.getCasesInASingleDay();
            List<String> bList = b.getCasesInASingleDay();

            if (aList == null || bList == null || aList.isEmpty()) {
                return 0;
            }

            int aLast = Integer.parseInt(aList.get(aList.size() - 1));
            int bLast = Integer.parseInt(bList.get(bList.size() - 1));

            return Integer.compare(bLast, aLast);
        });
    }
}

/* =========================================================
   🔥 FEATURE 3: TOTAL CASES CALCULATOR
   ========================================================= */
@org.springframework.stereotype.Component
class TotalCasesFeature implements CovidFeatureProcessor {

    @Override
    public void apply(List<NewWebData> data) {

        for (NewWebData d : data) {

            int total = 0;

            for (String v : d.getCasesInASingleDay()) {
                total += Integer.parseInt(v);
            }

            System.out.println(
                    "Country: " + d.getCountry()
                            + " | Total Cases: " + total
            );
        }
    }
}