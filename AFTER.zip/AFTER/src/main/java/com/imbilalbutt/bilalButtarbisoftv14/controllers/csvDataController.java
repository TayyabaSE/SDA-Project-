package com.imbilalbutt.bilalButtarbisoftv14.controllers;

import com.imbilalbutt.bilalButtarbisoftv14.service.getCsvDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class csvDataController {

    @Autowired
    private getCsvDataService csvData;

    @GetMapping("/csvData")
    public String getData(Model model) {

        csvData.fetchData();

        model.addAttribute("data", csvData.getAllStats());

        return "csvData";
    }
}
