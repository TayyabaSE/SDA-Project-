package com.imbilalbutt.bilalButtarbisoftv14.service;

import com.imbilalbutt.bilalButtarbisoftv14.models.NewWebData;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import java.net.http.HttpClient;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest;
import java.net.URI;
import java.util.*;

@Service
public class readCsvDataWithRespectToDate {

    private String csv_file_url =
            "https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/"
            + "csse_covid_19_data/time_series_covid19_confirmed_global.csv";

    private List<NewWebData> allStats = new ArrayList<>();

    private String dateSince = "3/5/20";

    public void setDate(String dateSince) {
        this.dateSince = dateSince;
    }

    public void fetchData() {

        try {

            HttpClient client = HttpClient.newHttpClient();

            HttpRequest rqst = HttpRequest.newBuilder()
                    .uri(URI.create(csv_file_url))
                    .build();

            HttpResponse<String> rspns =
                    client.send(rqst, HttpResponse.BodyHandlers.ofString());

            CSVParser parser =
                    CSVParser.parse(rspns.body(), CSVFormat.DEFAULT);

            List<CSVRecord> records = parser.getRecords();

            if (records == null || records.isEmpty()) return;

            CSVRecord header = records.get(0);

            List<Object> list = new ArrayList<>();
            for (int i = 0; i < header.size(); i++) {
                list.add(header.get(i));
            }

            int beginIndex = list.indexOf(this.dateSince);
            if (beginIndex == -1) beginIndex = 4;

            this.allStats.clear();

            for (int i = 1; i < records.size(); i++) {

                CSVRecord row = records.get(i);

                List<String> rowList = new ArrayList<>();
                for (int j = 0; j < row.size(); j++) {
                    rowList.add(row.get(j));
                }

                List<String> subList =
                        rowList.subList(beginIndex, rowList.size());

                this.allStats.add(
                        new NewWebData(
                                rowList.get(1),
                                rowList.get(0),
                                subList
                        )
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Bean
    public List<NewWebData> getAllStats() {
        return allStats;
    }
}